
Mr. Cat's Minecraft Clone - Hosting Instructions

1. This package currently uses an iframe to Eaglercraft's official 1.5.2 demo.
2. To enable full keyboard control, you must download the Eaglercraft 1.5.2 game files yourself
   from https://github.com/lax1dude/eaglercraft or a trusted mirror.
3. Replace the iframe src in index.html with a relative path to your hosted files.
4. Upload this package to GitHub Pages or Netlify:
   - For GitHub Pages: create a repository, push these files, then enable Pages from main branch.
   - For Netlify: drag and drop the folder to deploy.
5. Once hosted, embed the URL in your Google Site via an iframe tag:
   <iframe src="https://yourusername.github.io/repo-name/" width="100%" height="600" allowfullscreen></iframe>

Enjoy your Minecraft adventures, Mr. Cat!

-- ChatGPT
